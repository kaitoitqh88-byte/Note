#!/bin/bash
python3 portable_launcher.py --start 2>/dev/null || python portable_launcher.py --start