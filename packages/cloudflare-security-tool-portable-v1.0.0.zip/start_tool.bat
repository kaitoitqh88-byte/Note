@echo off
python portable_launcher.py --start
pause