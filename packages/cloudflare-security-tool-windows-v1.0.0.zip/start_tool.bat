@echo off
echo 🛡️ Cloudflare Security Tool
echo ==========================

python portable_launcher.py --start
if %errorlevel% neq 0 (
    echo.
    echo Python not found. Opening tool directly...
    start cloudflare_security_tool.html
)
pause
