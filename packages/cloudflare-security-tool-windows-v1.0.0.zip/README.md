# 🛡️ Cloudflare Security Rules Tool v1.0.0

Portable Cloudflare Security Rules Management Tool

## 🚀 Quick Start

### Windows
- Double-click `start_tool.bat` or `start_tool.ps1`
- Or run: `python portable_launcher.py --start`

### macOS/Linux  
- Run: `./start_tool.sh`
- Or run: `python3 portable_launcher.py --start`

### Universal
- Run: `python portable_launcher.py` (interactive menu)
- Or open `cloudflare_security_tool.html` directly in browser

## ⚙️ Setup

1. Copy `config.json.template` to `config.json`
2. Edit with your Cloudflare API credentials:
   - Email address
   - Global API Key
   - Zone ID
3. Launch using one of the methods above

## 📋 Features

- ✅ Create/Edit/Delete Cloudflare security rules
- ✅ Pre-built security templates
- ✅ Expression validation
- ✅ Real-time rule management
- ✅ Cross-platform compatibility
- ✅ Portable - no installation required
- ✅ Local web interface

## 🔧 Requirements

- Modern web browser (Chrome, Firefox, Safari, Edge)
- Python 3.6+ (for local server, optional)
- Cloudflare account with API access

## 🛠️ API Setup

1. Go to Cloudflare Dashboard → My Profile → API Tokens
2. Use Global API Key OR create custom token
3. Get Zone ID from domain overview page
4. Configure in `config.json`

## 📞 Support

- 📚 Full documentation in tool interface
- 🐛 Check console for error messages
- ⚙️ Verify API credentials
- 🔧 Ensure Python is installed for server mode

## 🔐 Security Notes

- API keys are stored locally only
- HTTPS connections to Cloudflare API
- No data sent to third parties
- Local tool execution

---

**Happy securing your Cloudflare zones! 🛡️**
