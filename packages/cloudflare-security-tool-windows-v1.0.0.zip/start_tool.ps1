# Cloudflare Security Tool - PowerShell Launcher
Write-Host "🛡️ Cloudflare Security Tool" -ForegroundColor Cyan
Write-Host "=========================="

try {
    python portable_launcher.py --start
} catch {
    Write-Host "Python not found. Opening tool directly..." -ForegroundColor Yellow
    Start-Process "cloudflare_security_tool.html"
}
