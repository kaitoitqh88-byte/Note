#!/bin/bash
echo "🛡️ Cloudflare Security Tool"
echo "=========================="

if command -v python3 &> /dev/null; then
    python3 portable_launcher.py --start
elif command -v python &> /dev/null; then
    python portable_launcher.py --start
else
    echo "Python not found. Opening tool directly..."
    xdg-open cloudflare_security_tool.html 2>/dev/null || firefox cloudflare_security_tool.html 2>/dev/null || echo "Please open cloudflare_security_tool.html in your browser"
fi
