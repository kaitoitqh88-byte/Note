#!/bin/bash
echo "🛡️ Cloudflare Security Tool"
echo "=========================="

if command -v python3 &> /dev/null; then
    python3 portable_launcher.py --start
elif command -v python &> /dev/null; then
    python portable_launcher.py --start
else
    echo "Python not found. Opening tool directly..."
    open cloudflare_security_tool.html
fi
